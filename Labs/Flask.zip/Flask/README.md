# Flask-REST-Template
 Folder structure for a simple flask rest app
